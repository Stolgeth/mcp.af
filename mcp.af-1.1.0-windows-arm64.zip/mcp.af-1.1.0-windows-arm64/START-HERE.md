# mcp.af 1.1.0

1. Open a local Codex task on the computer where Affinity is installed.
2. Attach this ZIP, or give the agent its local file path.
3. Paste the text in AGENT-PROMPT.txt.
4. Confirm the desktop Codex profile selected by the agent. It must not belong to a sandbox account.
5. If the operating system denies writing there, run the supplied command in a normal terminal under your desktop account.
6. After verified registration, restart Codex and open a new task. Plugin: mcp.af. Skill: mcp-af.

The agent runs the included installer; the ZIP does not execute itself. No
separate Node.js/npm installation is needed. Use the package for your native
architecture: Windows x64, Windows ARM64, or macOS Apple Silicon (ARM64).

Affinity must be installed separately and its MCP server enabled for the
connection check to pass. This is a local desktop integration, not a cloud
connector. Affinity, ChatGPT and Codex accounts/features have their own terms.

Read INSTALL.md for commands, troubleshooting and removal. Windows x64 has
automated/local test coverage; the maintainer confirms successful native use
on Windows ARM64 and macOS Apple Silicon. Validation details are published
alongside the release downloads.

By Tomáš Trlíček / Stolgeth. Independent integration. Free personal and
commercial use; modification of original additions requires permission.
See LICENSE and THIRD-PARTY-NOTICES.txt.
