---
name: mcp-af-install
description: Install, verify or remove an mcp.af desktop ZIP on the local computer using its bundled installer. Use when the user requests installation of this package.
---

# Install mcp.af

The user must request installation. Reading this skill alone is not permission
to install. Use a local task with filesystem and command execution on the
computer running Affinity. A cloud-only task cannot install into that computer.

Locate the extracted package and read its INSTALL.md, build-info.json and
setup/install.mjs. This skill is at agent-skills/mcp-af-install/;
the package root is two levels above it. If only a ZIP path is supplied,
extract it into a new staging directory, rejecting absolute/traversal entries.

Use the bundled runtime matching the host's native OS and CPU. Windows uses
runtime/node.exe; Apple Silicon uses runtime/bin/node. Do not install Node,
npm dependencies or a second MCP bridge. Verify the package with the bundled
installer before installation; compare the outer ZIP checksum with the user's
trusted release checksums when available. Self-contained checksums detect
corruption, not the publisher's identity.

Use the supported Codex plugin CLI in the same desktop user's environment.
First establish the absolute profile used by the desktop app. Pass it as
--codex-home on install, doctor and uninstall, including --no-register. Do not
infer the desktop profile from the agent's HOME, USERPROFILE, LOCALAPPDATA or
inherited CODEX_HOME. Use trusted desktop launch context or the user's confirmed
path; ask if it is ambiguous. Never select CodexSandboxOffline/Online as the
target. The profile must already exist. Show the selected profile before running
the installer. Windows x64/ARM64 and macOS ARM64 follow the same rule.

Resolve its actual executable from PATH or the host's installation; pass it
with --codex if it is not on PATH. Read its plugin help if needed. Do not guess
or edit private app databases. If this host lacks the required plugin commands,
prepare with --no-register and explain the supported local marketplace UI
handoff; do not claim the plugin is installed.

Run setup/install.mjs install --dry-run first, then install using the same
arguments. Respect host permission requests. Keep the permanent destination
bound to that profile: by default it is <codex-home>/mcp-af. For an
update to an existing mcp.af installation, use the same profile and permanent
root. Read UPDATING.md and the new release notes before switching versions.
The installer probes writes before copying files. If OS access is denied,
provide its exact quoted command for a normal PowerShell window (Windows) or
Terminal (macOS) under the desktop user. Do not claim an agent permission grant
changes the OS account, alter ACLs, or retry under another user's profile.
Keep the permanent destination outside the extracted/downloaded directory.
Preserve existing settings and
other plugins. The installer owns only its dedicated marketplace. 

Run doctor with the same explicit profile, root and CLI. Require actual enabled
registration, cached skill and runtime checks to pass; saved installer state or
a successful connection alone is insufficient. Report registration and Affinity
connectivity separately, including the exact target profile. Name the installed
plugin mcp.af and its skill mcp-af. Exit 3 means registration was
not verified; exit 2 means connection unavailable after verified registration.
Doctor does not modify documents.
Never create an artboard merely to test installation unless the user asks.
After registration changes, tell the user to restart Codex and open a new local
task. The installer cannot establish that the running desktop has reloaded.

Do not repair errors by modifying the packaged adapter or ignoring architecture
checks. On a registration error, inspect the reported state, resolve the cause,
and rerun the same installer. A repeated unresolved error needs a clear report,
not a loop. Do not disable Gatekeeper, SmartScreen or other security controls.

Uninstall only when requested. The uninstall command removes this package's
plugin and marketplace registrations and retains files for recovery. Never
remove Affinity documents, the user's other scripts or unrelated plugins.
