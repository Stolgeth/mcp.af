---
name: mcp-af
description: Control and inspect Affinity through the mcp.af connector in Codex or compatible local ChatGPT environments. Use for documents, layers, vector and raster work, artboards, text, rendering, exports and SDK scripts. Prefer this connector over UI automation.
---

# mcp.af

Use the MCP connector for Affinity reads and edits. A successful tool result is connection evidence; do not precede every call with `affinity_status`. Status can be cached and includes its timestamp. If tools remain unavailable after one status check, request a plugin reload or a new task. An authorized connector audit may use a direct SDK client.

## Choose the appropriate interface

Use general SDK scripts and upstream tools for document, layer, vector, raster, selection, formatting and file operations. Read only the relevant live SDK topics. The specialized batch tools below are shortcuts for matching tasks, not a restriction on other Affinity work. `affinity_inspect_document` also supports ordinary documents and `include_layers:true` for a top-level layer inventory.

- `affinity_create_artboard_grid`: new editable document, numbered artboards and centered number fields in one call. Set count, columns, width, height and gaps. Each call creates a new document; never blindly repeat it.
- `affinity_inspect_document`: obtain the document UUID, history position and artboards. Request text only when needed; respect pagination and text truncation flags.
- `affinity_number_artboards`: number an existing named field on an explicit ordered artboard list.
- `affinity_correct_text`: exact before/after corrections, optional targeted ranges and shared-story handling.
- `affinity_arrange_artboards`: arrange equal-size artboards and optionally center a named text field. Use after numbering or length-changing corrections, since text widths change.
- `affinity_preview_artboard`: native cropped PNG. Use `render_spread` for the full layout. Render once after a completed visual batch.

Read [batch-tools.md](references/batch-tools.md) for parameters, limitations and correction examples. These built-in operations handle preflight, batched commands, readback and preamble loading internally. Do not spend separate calls loading SDK documentation for them.

Retain the target session UUID. Existing-document writes check that it is active; an optional history position detects stale plans. Reopening a file changes its UUID. Exact names must be unique within the target spread/artboard. Already-correct values are skipped. A compound command is an undo unit, not a transaction or guaranteed rollback.

For proofreading, inspect text in batches and distinguish likely typos from intentional names or specialist terms; use exact corrections and preserve formatting. For layer organization, inspect hierarchy and stacking order before renaming or moving layers, then verify both names and relationships. For pixel alignment before export, determine the document units and pixel scale first: fractional displayed coordinates are not necessarily fractional pixels. Check artboard positions in pixel space, preserve dimensions and child placement relative to each artboard, and read back the changed positions. Do not silently round unrelated object geometry or export files unless requested.

## Custom SDK scripts

Read `preamble` once per upstream connection before authoring raw scripts, followed only by relevant topics. Reuse loaded documentation. A changed `affinityConnectionGeneration` or preamble-required response invalidates readiness. Use current `/module.js` imports. See [sdk-notes.md](references/sdk-notes.md) for verified 3.3 behavior.

For reusable library scripts, read [scripts-and-brand-kit.md](references/scripts-and-brand-kit.md): list and inspect the intended source before execution; save only self-contained code when requested and verify its readback. Running saved source through MCP does not carry the entry's resource bundle or panel configuration.

For placed SVG artwork, including assets placed from Brand Kit, use the same reference to distinguish editable vectors, embedded documents and unknown representations before editing. Preserve clipping and hierarchy; never silently flatten or rebuild artwork. Brand Kit panel browsing, placement and settings are outside this workflow.

Keep SDK handles within one script. Snapshot lazy children with `[...node.children]`, preflight every target, build a coherent compound command, then verify all affected values in that same call. Serialize mutations. Use semantic field names and explicit insertion targets for creation.

By default `execute_script` returns `{ok,value,logs}` and sets `isError` for caught exceptions or unconfirmed execution. It waits for a returned promise; `async:true` enables top-level `await`. Await every asynchronous task whose completion must be verified. `ok:true` confirms script completion, not that the intended edit happened: return explicit readback. Unawaited callbacks are outside that completion contract.

For existing scripts requiring Affinity's original execution context, use `mode:"native"`. Source and result pass through unchanged; native error flags can be unreliable, so require explicit success output and readback. After any timeout, exception or missing reply, inspect state before deciding what remains; requests are never automatically replayed.

Text ranges are story-global **Unicode code-point offsets**, not JavaScript UTF-16 string indices. Use `Array.from(text)` for offset calculations. Apply nonoverlapping replacements from right to left. Group linked frames by a canonical flow node with `isSameNode`, never by identical text content. Prefer substring corrections to preserve surrounding mixed formatting.
